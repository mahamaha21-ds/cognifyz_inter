import random
def number_guessering():
    print("Welcome to number guessing game!")
    starting_number=int(input("Enter a number starts from:"))
    ending_number=int(input("Enter the ending number:"))

    if starting_number>=ending_number:
        print("invalid number, Please enter the number between the range of start and end:")
        return

    random_number = random.randint(starting_number, ending_number)
    attempts = 0


    while True:
        try:
            guessing=int(input(f"Enter a number between {starting_number} to {ending_number}:"))
            attempts+=1

            if guessing < starting_number or guessing > ending_number:
                print("please enter the number between the start and end:")
            elif guessing < random_number:
                print("guess is too low")
            elif guessing > random_number:
                print("guess is too high")
            else:
                print(f"Congratulations! You guessed it in {attempts} attempts.")
                break
        except ValueError:
            print("Invalid input,please enter the valid number")


number_guessering()