import string
from collections import defaultdict

def file_manipulation(filename):
    counting = defaultdict(int)

    try:
        with open(filename, 'r', encoding='utf-8') as file:
            for line in file:
                line = line.translate(str.maketrans('', '', string.punctuation)).lower()
                words = line.split()
                for word in words:
                    counting[word] += 1

        for word in sorted(counting):
            print(f"{word}: {counting[word]}")

    except FileNotFoundError:
        print(f"Error: The file '{filename}' was not found.")

if __name__ == "__main__":
    filename = input("Enter the name of the text file: ")
    file_manipulation(filename)
