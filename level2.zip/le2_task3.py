import re
def password_strength_checker(password):
    score=0
    if len(password)>=8:
        score+=1
    else:
        print("Atleast 8 character should be entered")

    if re.search(r'[a-z]',password):
        score+=1
    if re.search(r'[A-Z]',password):
        score+=1
    if re.search(r'\d',password):
        score+=1
    if re.search(r'[!@#$%^&*()_{};:".,\|/?<>]',password):
        score+=1


    if score>=5:
        strength="strong"
    elif score>=3:
        strength="moderate"
    else:
        strength="weak"

    print(strength, f"password strength")
    print(score,f"out of 5,your score of the password")


password=input("enter the password:")
password_strength_checker(password)

