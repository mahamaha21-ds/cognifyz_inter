
guessing_number=20
while True:
    choose=int(input("guess the number between 1 to 100:"))

    if choose==guessing_number:
        print("Congrats! you guessed the number.")
        break
    elif choose>=50 and choose<=100:
        print("It's too high!")
    elif choose>=30:
        print("It's high!")
    elif choose>=25:
        print("You got closer!")
    elif choose>=15 and choose<=25:
        print("You got closer!")
    elif choose>=1 and choose<=15:
        print("Somewhat closer")
        break
    else:
        print("Invalid,","please guess the number between 1 to 100:")

